<?php
include_once("class.punktacja.php");
class gracz
{
    private $name;
    private $surname;
    private $gameScore;


    public function __construct($name, $surname)
    {
        $this->name = $name;
        $this->surname = $surname;
        $this->gameScore = new punktacja();
    }

    public function __destruct()
    {
        $outputScore = $this->gameScore->__destruct();
        return "Player: " . $this->name . " " . $this->surname. " Final score: ".$outputScore;
    }

    public function updatePlayersScore($amount = 0)
    {
        return $this->gameScore->addScore($amount);
    }
}
