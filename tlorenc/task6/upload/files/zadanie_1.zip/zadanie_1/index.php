<?php
include_once("classes/class.gracz.php");

$newPlayerOne = new gracz("Player", "One");
$newPlayerTwo = new gracz("Player", "Two");


$newPlayerOne->updatePlayersScore(32);
$newPlayerOne->updatePlayersScore(-31);
$newPlayerTwo->updatePlayersScore(1020);
$newPlayerTwo->updatePlayersScore(-1212);
$newPlayerTwo->updatePlayersScore(23);
$newPlayerTwo->updatePlayersScore(-11001);

$output = $newPlayerOne->__destruct();
echo $output."<br>";

$output = $newPlayerTwo->__destruct();
echo $output;